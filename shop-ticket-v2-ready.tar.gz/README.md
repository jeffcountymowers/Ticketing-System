# Shop Ticket V2

A responsive shop-management PWA for small-engine repair work. It is designed for iPhone and desktop with one shared Supabase database.

## Included in V2
- Customer records: name, phone, address, notes
- Equipment records linked to customers
- Repair tickets with automatic ticket numbers
- Status workflow: New → Diagnosing → Waiting for Approval → Waiting for Parts → Repairing → Ready for Pickup → Completed
- Estimates and approval status
- Diagnosis, requested work, parts needed, work performed, technician notes
- Customer history showing equipment and prior tickets
- Search across customers, equipment, and tickets
- Mobile-first touch controls
- Supabase Auth + PostgreSQL with row-level security

## Setup
1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL editor.
3. Copy `.env.example` to `.env` and add the Supabase project URL and anon key.
4. Run `npm install` and `npm run dev`.
5. Deploy the Vite site to an HTTPS host.
6. Open the HTTPS site in Safari on iPhone → Share → Add to Home Screen.

## Important
This package is the deployable V2 source, but it is **not yet a live hosted app** because no hosting/database account has been connected from this chat. Once a Supabase project and HTTPS host are connected, the same database is used by both phone and desktop.
